"use strict";

const validationMethods = {

    length(field, args) {
        const valLength = field.value.length,
            sign = args[0],
            then = args[1];

        let message = null;
        switch (sign) {
            case '>':
                if (!(valLength > then)) {
                    message = `Минимальная длина поля ${then + 1}`;
                }
                break;
            case '<':
                if (!(valLength < then)) {
                    message = `Максимальная длина поля ${then - 1}`;
                }
                break;
            case '>=':
                if (!(valLength >= then)) {
                    message = `Минимальная длина поля ${then}`;
                }
                break;
            case '<=':
                if (!(valLength <= then)) {
                    message = `Максимальная длина поля ${then}`;
                }
                break;
            case '==':
                if (!(valLength === then)) {
                    message = `Длина поля должна равняться ${then} символам`;
                }
                break;
        }

        return message;
    },


    containsOnlyNumbers(field) {
        for (const val of field.value) {
            if (!Number.isInteger(Number.parseInt(val))) {
                return 'Поле должно содержать только цифры';
            }
        }

        return null;
    },

    fieldsMatch(field, args) {
        return field.value !== document.querySelector(args[0]).value ? 'Поля не совпадают' : null;
    },
};

const form = {
    formElement: null,
    rules: null,


    init() {
        this.formElement = document.querySelector('.my-form');
        this.formElement.addEventListener('submit', event => this.formSubmit(event));

        this.rules = [
            {
                selector: 'input[name="name"]',
                methods: [
                    {name: 'length', args: ['>=', 1]},
                    {name: 'length', args: ['<=', 50]},
                ],
            },
            {
                selector: 'input[name="phone"]',
                methods: [
                    {name: 'containsOnlyNumbers'},
                    {name: 'length', args: ['==', 11]},
                ],
            },
            {
                selector: 'input[name="password"]',
                methods: [
                    {name: 'length', args: ['>=', 5]},
                    {name: 'length', args: ['<=', 50]},
                ],
            },
            {
                selector: 'input[name="password_repeat"]',
                methods: [
                    {name: 'fieldsMatch', args: ['input[name="password"]']},
                    {name: 'length', args: ['>=', 5]},
                    {name: 'length', args: ['<=', 50]},
                ],
            },
        ];
    },


    formSubmit(event) {
        if (!this.validate()) {
            event.preventDefault();
        }
    },

    validate() {
        let isValid = true;
        for (let rule of this.rules) {
            const inputElement = document.querySelector(rule.selector);
            for (let method of rule.methods) {
                const validFunction = validationMethods[method.name];
                const errorMessage = validFunction(inputElement, method.args);

                if (errorMessage) {
                    this.setInvalidField(inputElement, errorMessage);
                    isValid = false;
                    break;
                } else {
                    this.setValidField(inputElement);
                }
            }
        }

        return isValid;
    },

    setInvalidField(inputElement, message) {
        const lvl = inputElement.classList;
        lvl.remove('is-valid');
        lvl.add('is-invalid');

        let hint = inputElement.parentElement.querySelector('.invalid-feedback');
        if (!hint) {
            hint = document.createElement('div');
            hint.classList.add('invalid-feedback');
            inputElement.parentNode.appendChild(hint);
        }
        hint.textContent = message;
    },

    setValidField(inputElement) {
        const lvl = inputElement.classList;
        lvl.remove('is-invalid');
        lvl.add('is-valid');
    }
};

form.init();